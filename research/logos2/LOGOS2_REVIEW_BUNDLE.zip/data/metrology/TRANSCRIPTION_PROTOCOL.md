# E204 fraction-apparatus transcription protocol (frozen BEFORE extraction)

**Source:** Younger web corpus, archived Wayback captures (see SOURCE_REGISTER.csv; sha256 +
capture dates in corpus/bronze/younger_lineara/PROVENANCE.md). Licence posture: personal
scholarly website, no explicit licence → factual sign-occurrence extraction for internal
research with citation; NO redistribution of the pages; the derived CSV records factual
epigraphic content (doc id, position, integer, fraction letters) only.

## Extraction rules (two independent passes; agreement required)
- **Admissible lines ONLY:** line-anchored transcription patterns `"<locus> <WORD/LOGO tokens>
  <INT>? <FRACLETTERS>"` where FRACLETTERS ∈ {J,E,F,K,L,H,B,DD,JE,EF,...} as standalone
  capital-letter tokens inside a transcription locus (a.1, b.2-3, …).
- **HARD EXCLUSION — commentary contamination:** any line containing English prose markers
  (e.g. "gave", "distribute", "according", "perhaps") or DECIMAL glosses (\d+\.\d+ — Younger's
  own interpreted values like "8.50") is EXCLUDED from the apparatus; these are his
  interpretations, not epigraphy. Counted in QUALITY_REPORT as excluded_commentary.
- **Uncertain readings:** tokens marked `?`, `[ ]` (restorations), `{ }` (editorial) → the
  record is kept with flags uncertain=1 / restored=1 and EXCLUDED from arithmetic constraints
  by default (sensitivity arm may re-include restored-only).
- **Duplicates:** document identity keyed by Younger's designation (e.g. HT 8); when a document
  appears in multiple files, the HTtexts/misctexts/religioustexts precedence order applies and
  the duplicate is logged.
- **Double-entry equivalent:** two INDEPENDENT parsers (different tokenization strategies,
  written separately) must agree per record; disagreements go to a manual-adjudication queue
  and are excluded until adjudicated. Target agreement ≥ 98% before the data gate opens.
- **Arithmetic constraint extraction** (separate pass, stricter): only documents whose
  transcription includes an internally-complete entry list AND a KU-RO total line, all
  quantities unflagged. Everything else is descriptive-occurrence data only.

## Gate to E204 execution
FRACTION_APPARATUS.csv complete + QUALITY_REPORT agreement ≥98% + ≥30 multi-fraction documents
+ ≥10 arithmetic-complete documents. Below that, E204 stays BLOCKED with the shortfall stated.
The FRACTION_ORDER seal's opening event (Anetaki II publication) has NOT occurred; no seal is
opened regardless of this gate.
