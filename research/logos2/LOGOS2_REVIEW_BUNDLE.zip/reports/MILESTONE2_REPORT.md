# LOGOS-2 Milestone-2 Report

**Date:** 2026-07-10 · **Branch:** `research/logos2-anchor-identifiability` · **Governance:**
Constitution v2.3 + `CLAIM_LADDER.md` + `MILESTONE2_CONTROL_ADDENDUM.md` (@`5deec1e`, frozen
before any confirmatory inspection). Machine-readable: `MILESTONE2_SUMMARY.json` ·
claims: `MILESTONE2_CLAIM_LEDGER.csv` · hashes: `MILESTONE2_MANIFEST.sha256`.

**One line:** the milestone produced a certified-calibration negative on replay qualification, an
exact (model-conditional) identifiability count, three clean generic-verdict adjudications, one
data-blocked branch with a filed unblock path, a frozen 151-candidate onomastic slot set — and
**no claim above L0 graduated**. Linear A is *not* thereby shown undecipherable; every negative
is model- and data-conditional, with the evidence that would change it named.

## The ten frozen questions

**1. Did any syllabic historical replay qualify?** **No.** Under the frozen rule (R_full = 10
fit-anchors + 10% fit-bilingual, holdout-only scoring): Linear B→Greek **0.000** (threshold
0.50), Cypriot→Greek **0.005 ≈ chance** (threshold 0.35). Ugaritic→Hebrew reached 0.486
(chance 0.0006) but is alphabetic — never sufficient — and fell below its own 0.60 threshold;
its above-chance recovery is additionally discounted because 34.4% of its cipher words are
byte-identical to plain words (dataset-inherent Semitic cognate identity in shared romanization;
the syllabic datasets are 0% identical and leak-clean). **Status class:
`ALPHABETIC_REPLAY_ONLY_NOT_QUALIFIED_FOR_LINEAR_A`.** The current EM implementation may not be
used for positive Linear A inference (frozen marking applies). No rerun was performed.

**2. What is the exact false-graduation upper bound?** **0/200 false graduations; exact
one-sided Clopper–Pearson 95% upper bound = 1.49% ≤ the committed 2% target → the calibration
arm is CERTIFIED.** Composition 67 synthetic-isolate / 67 shuffled-inventory / 66
unrelated-target null campaigns at the leak-clean Linear B regime, with the full frozen pipeline
(including abstention) inside every null. The certificate attaches to the false-positive
behaviour only — it says nothing about recovery capability (which failed syllabically).

**3. Did E203 identify any non-generic domain contraction?** **No.** The surviving-solution
count under the WPH-38 pin system with model-2 semantics is **10^224.83 — an EXACT count, but
strictly conditional on the encoded WPH38/model-2 domain (67-cell CV grid), the encoded
constraint set (65 substitution edges with same-C-or-same-V semantics, pin-violated edges
dropped), and the component-wise factorization** (largest coupled component: 6 signs). It is not
a statement about Linear A per se — it is the ambiguity of that model of the evidence. All
minimal unsatisfiable cores have size 2 (single pin-pair collisions) and are typical of matched
random pin sets; value-permutation and frequency-preserving nulls are UNSAT 200/200; the
soft-formulation's always-violated set is stable across weight bands ×0.25–×4. Every
contraction observed is attributable to pin count, not to which hypothesis supplied the pins.

**4. Which hypothetical observation has the highest expected information value?** By measured
Δlog₁₀ (consistent-anchor): **bilingual fragment +17.95** — but with the worst measured
wrong-observation fragility (0.20) and no known availability. By availability-weighted expected
value the ranking inverts: **(1) GORILA fraction-apparatus ingestion** (in-house, licence-clean,
unblocks E204 whole-channel), **(2) Anetaki II edition on publication** (seal opening event +
toponym-class anchors, +7.25/anchor), then secure toponym (+7.25), secure name (+5.45),
new sparse-site inscription (+1.83/pin; also the prospective A-initial test). Full table:
`experiments/E202_acquisition_policy/VALUE_OF_INFORMATION.csv`.

**5. Did metrology survive component ablation and selection-aware nulls?** **Not reached — and
not a negative result.** E204 is **BLOCKED_DATA**: the accessible corpus carries 12
fraction-sign tokens across 10 documents (exactly 1 multi-fraction document), so the epigraphic
arithmetic constraint system is unpowered. No cell ran; the seal was neither opened nor read;
the exact missing record set (per-document fraction sequences with quantities — the GORILA
klasmatogram apparatus) and the unblock path (an in-house silver-ingestion task) are filed.

**6. Did Salgarella grades change identifiability without assuming phonetic identity?** **No —
PRIOR_GENERIC.** Treated as palaeographic evidence with graded weights, the prior's
identifiability effect is indistinguishable from pin count (grade-permutation nulls); the real
grade assignment is itself inconsistent with the substitution channel under model-2 dropping,
and the hard-identity arm was already UNSAT_GENERIC 200/200. Sign-shape continuity was never
treated as phonetic-value identity. (E205-A/B measurement cells deferred with reason; E205C
remains BLOCKED_DATA.)

**7. Did A participate in a predictive paradigm?** **No — POSITIONAL_ONLY.** Under the
preregistered M0–M6 battery (including first-time adaptor-PYP and subregular legs), no
stem/clitic/adaptor model beats the positional null after complexity charging on held-out
unseen types (M3 11.6 vs M2 6.8 bits/sign); zero recurring stems and zero alternant stems at
the preregistered thresholds. One defect-repair amendment (probability sign error) was
committed with the invalid as-run preserved. The established statement stands unchanged: *A is
strongly enriched in initial position across overlapping segmentation variants* — nothing more.

**8. Was the onomastic candidate set frozen without external-name contamination?** **Yes.**
151 candidates from internal structure only (87 entry-head / 60 totals-adjacent / 10
formula-slot-2 / 14 cross-site / 25 site-local), with the formula head `A-TA-I-*301-WA-JA`
derived mechanically from document-initial position — not imported. Four candidates carrying
prior published exposure are flagged into a separate exploratory stratum (barred from
confirmatory graduation). Zero external name inventories were loaded before the freeze
(`SLOT_FREEZE.sha256`).

**9. Is E208 still de-authorized?** **Yes: `DE_AUTHORIZED_PENDING_LICENSE_CLEAN_GATE`** — and
now doubly so, since the syllabic E201 qualification (a hard precondition) failed.

**10. Did any result legitimately graduate above L0?** **No.** The milestone's positive
products are L0 tooling/calibration facts (a certified-calibration harness, an exact
model-conditional identifiability engine, a frozen slot set, a measured VOI table). The
campaign-level interpretation remains: relative structure is real; value assignment stays
underdetermined by the accessible evidence; the bottleneck is anchors, not algorithms.

## Amendment and discipline record (this milestone)

Two defect-repair amendments, both committed before their reruns with as-run artifacts
preserved: E203 G1 gate criterion (instance-luck → reference-equality) and E207 stem-probability
sign error. One dataset-inherent leak adjudicated (uga-heb cognate identity). Protected assets
re-verified ALL-OK; prospective seals unread; no hard pins were added in response to any
UNSAT_GENERIC; unproductive branches recorded as exhausted-under-current-evidence, not
impossible. E201-F1b remains pending the CSA sweep under the import boundary.
